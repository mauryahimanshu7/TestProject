Airline Ticket Booking System
                                    
Spring MVC and Hibernate application through which customers can browse flights schedule and ticket availability between 2 locations for a particular date and then login or signup and book ticket. Customers’ gets an email confirmation when they book the ticket as well as a pdf view of booked ticket is available. A customer can cancel ticket as well
Implemented unique username validation using AJAX. Admin can add/delete airline as well as add/update/delete flight and can view all passengers for flights